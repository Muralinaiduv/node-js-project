module.exports = [
    {
        id: 1,
        title: "The Porter",
        author: "Naidu",
        price: 100,
        description: "Good book to tell about harry porter",
        release: "6-0801997"
      },
      {
        id: 2,
        title: "king of author",
        author: "Murali",
        price: 1200,
        description: "describes about king",
        release: "09-07-1997"
      },
      {
        id: 3,
        title: "mount of each",
        author: "raju",
        price: 1000,
        description: "tells about mount of each other",
        release: "10-08-1996"
      },
]